@echo off
:: ============================================================
:: OpenClaw Post-Setup - Run AFTER restart (inside WSL)
:: Right-click -> Run as Administrator
:: ============================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting admin privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================================
echo   OpenClaw Post-Setup (run after restart)
echo ============================================================
echo.
echo This runs inside WSL Ubuntu to complete OpenClaw setup.
echo.

wsl -d Ubuntu -- bash -c "curl -s http://100.116.78.121:8888/postsetup.sh | bash; echo ''; echo 'If curl failed, run manually:'; echo '  cd /mnt/c/Users/%USERNAME%/Downloads/openclaw-setup'; echo '  bash openclaw-employee-postsetup.sh'"

echo.
pause
