OpenClaw Employee Setup
=======================

How to install:
1. Right-click openclaw-setup.bat
2. Select "Run as Administrator"
3. Follow the on-screen instructions
4. If laptop restarts, run it again after restart

That's it!

Requirements:
- Windows 10 (Build 19041+) or Windows 11
- Admin rights on the laptop
- Internet connection
